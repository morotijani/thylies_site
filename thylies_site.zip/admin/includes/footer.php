<!-- FOOTER -->
			</main>
		</div>
	</div>

	<script src="<?= PROOT; ?>assets/js/jquery.min.js"></script>
	<script src="<?= PROOT; ?>admin/dist/js/main.js"></script>
</body>
</html>